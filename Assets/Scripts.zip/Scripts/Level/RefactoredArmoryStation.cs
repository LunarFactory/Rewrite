using UnityEngine;
using Weapons;

namespace Level
{
    [RequireComponent(typeof(BoxCollider2D))]
    public class RefactoredArmoryStation : MonoBehaviour, IInteractable
    {
        public string GetInteractPrompt()
        {
            return "무기 변경 (Armory)";
        }

        public WeaponData[] weaponLibrary;

        public void OnInteract(GameObject interactEntity)
        {
            var ctrl = interactEntity.GetComponent<Player.PlayerController>();
            if (ctrl == null) return;

            int nextIndex = ((int)ctrl.currentWeapon.weaponData.Type + 1) % weaponLibrary.Length;
            WeaponData selectedData = weaponLibrary[nextIndex];

            ChangeWeapon(ctrl, selectedData);
        }

        public void ChangeWeapon(Player.PlayerController ctrl, WeaponData newData)
        {
            if (Core.RunManager.Instance != null)
            {
                Core.RunManager.Instance.CurrentWeaponData = newData; // (O)
            }
            UpdateWeaponComponent(ctrl, newData);
        }

        private void UpdateWeaponComponent(Player.PlayerController ctrl, WeaponData data)
        {
            ctrl.currentWeapon.weaponData = data;
            if (data.weaponSprite != null)
            {
                ctrl.currentWeapon.GetComponent<SpriteRenderer>().sprite = data.weaponSprite;
            }
        }
    }
}
